public class Field {
    private int x, y;
    private boolean isCorner;
    private boolean visited;

    public Field(int x, int y) {
        this.x = x;
        this.y = y;
        this.visited = false;
        this.isCorner = false;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void markAsCorner() {
        this.isCorner = true;
    }

    public boolean isCorner() {
        return isCorner;
    }

    public boolean isVisited() {
        return visited;
    }

    public void maskAsVisited() {
        this.visited = true;
    }

    public void markAsUnvisited() {
        this.visited = false;
    }

    @Override
    public String toString() {
        return getCharForNumber(x) + "" + (y+1);
    }

    private String getCharForNumber(int i) {
        return i >= 0 && i < 27 ? String.valueOf((char)(i + 97)) : null;
    }
}
