import java.util.List;
import java.util.Set;

public class Main {

    public static void main(String args[]) {
        Field startField = new Field(1, 1);
        Springerproblem s = new Springerproblem(3, startField, 1);

        s.findWayEasy(s.getField(0,0));

        Set<List<Field>> solutions = s.getSolutions();

        System.out.println(solutions.size() + " Solutions");


        for(List<Field> solution : solutions) {
            for(Field f : solution) {
                System.out.print(f.toString() + " - ");
            }
            System.out.println("\n");
        }
        /*
        List<Field> diese = s.getPossibleMoves(new Field(2, 1));
        for(Field f : diese) {
            System.out.println(f.toString());
        }*/


        /*
        List<Field> weg = s.easy(s.getField(1, 0), 0);

        if(weg != null) {
            for (Field f : weg) {
                System.out.println(f.toString());
            }
        } else {
            System.out.println("weg ist null");
        }
        */


    }
}
