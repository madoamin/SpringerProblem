import java.util.*;

public class Springerproblem {
    private int fieldSize;
    //varient
    private Field startField;
    private Set<List<Field>> solutions;
    private int solutionAmount;

    private Field[][] fields;

    private int moveNumber, cornerNumber;
    private List<Field> currentPath;

    public Springerproblem(int fieldSize, Field startField, /*varient*/ int solutionAmount) {
        this.fieldSize = fieldSize;
        this.startField = startField;
        this.solutionAmount = solutionAmount;

        this.moveNumber = 0;
        this.currentPath = new ArrayList<>();
        this.solutions = new HashSet<>();
        this.cornerNumber = 0;

        this.fields = new Field[fieldSize][fieldSize];
        for(int i = 0; i < fieldSize; i++) {
            for(int j = 0; j < fieldSize; j++) {
                fields[i][j] = new Field(i, j);
                if(i == 0 && j == fieldSize-1 || i == 0 && j == 0 || i == fieldSize-1 && j == 0 || i == fieldSize-1 && j == fieldSize-1) {
                    fields[i][j].markAsCorner();
                }
            }
        }
    }

    /*
    gibt alle möglichen Züge zurück.
     */
    public List<Field> getPossibleMoves(Field field) {
        List<Field> result = new ArrayList<>();
        int relativeIndices[][] = {{-1,-2},{1,-2},{2,-1},{2,1},{1,2},{-1,2},{-2,1},{-2,-1}};
        for(int[] delta : relativeIndices) {
            if(getField(field.getX() + delta[0], field.getY() + delta[1]) != null) {
                if(!(getField(field.getX() + delta[0], field.getY() + delta[1]).isVisited())) {
                    //if(this.board[field.getX() + delta[0]][field.getY() + delta[1]] <= 0) {
                        result.add(getField(field.getX() + delta[0], field.getY() + delta[1]));
                    //}
                }
            }
        }
        return result;
    }

    public List<Field> easy(Field startField, int solutionAmount) {
        List<Field> list = new ArrayList<>();
        List<Field> list2 = new ArrayList<>();
        List<Field> list3 = new ArrayList<>();
        return findWayEasy(startField, list, list3, list2);
    }

    private List<Field> findWayEasy(Field currentField, List<Field> solution, List<Field> visitedCorners, List<Field> visitedFields) {
        //currentField.maskAsVisisted();
        if(visitedCorners.size() == 4) {
            return solution;
        } else {
            if(!visitedFields.contains(currentField)) {
                visitedFields.add(currentField);
                if(currentField.isCorner()) {
                    visitedCorners.add(currentField);
                }
                for (Field f : getPossibleMoves(currentField)) {
                    System.out.println("hier : " + f.toString());
                    //List<Field> miese = findWayEasy(f, solution, visitedCorners);
                    if (findWayEasy(f, solution, visitedCorners, visitedFields) != null) {
                        solution.add(f);
                        //abspeichern eines Weges hier ? vermutlich
                        return solution;
                    }
                }
            }
        }
        //System.err.println("FEHLER - findWayEasy - sollte nicht passieren.");
        //System.exit(1);
        return null;
    }

    public void findWayEasy(Field currentField) {
        if(currentField.isCorner()) {
            this.cornerNumber++;
        }
        this.currentPath.add(currentField);
        currentField.maskAsVisited();
        if(this.hasSolutionEasy()) {
            List<Field> copy = new ArrayList<>(this.currentPath);
            this.solutions.add(copy);
        } else {
            List<Field> possibleMoves = this.getPossibleMoves(currentField);
            for(Field newField : possibleMoves) {
                this.findWayEasy(newField);
            }
        }
        if(currentField.isCorner()) {
            this.cornerNumber--;
        }
        this.currentPath.remove(currentField);
        currentField.markAsUnvisited();
    }

    public void findWayNormal(Field currentField) {
        this.moveNumber++;
        this.currentPath.add(currentField);
        currentField.maskAsVisited();
        if(this.hasSolutionNormal()) {
            List<Field> copy = new ArrayList<>(this.currentPath);
            this.solutions.add(copy);
        } else {
            List<Field> possibleMoves = this.getPossibleMoves(currentField);
            for(Field newField : possibleMoves) {
                this.findWayNormal(newField);
            }
        }
        this.moveNumber--;
        this.currentPath.remove(currentField);
        currentField.markAsUnvisited();
    }

    private boolean hasSolutionNormal() {
        return moveNumber >= this.getFieldSize() * this.getFieldSize();
    }

    public boolean hasSolutionEasy() {
        return cornerNumber >= 4;
    }

    public Set<List<Field>> getSolutions() {
        return this.solutions;
    }

    public Field getField(int x, int y) {
        if(x >= 0 && x < this.fieldSize && y >= 0 && y < this.fieldSize) {
            return fields[x][y];
        } else {
            return null;
        }
    }

    public int getFieldSize() {
        return fieldSize;
    }
}
